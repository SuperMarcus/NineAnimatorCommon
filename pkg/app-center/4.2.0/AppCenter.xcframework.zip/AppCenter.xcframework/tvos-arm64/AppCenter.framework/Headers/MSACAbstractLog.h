// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#ifndef MSAC_ABSTRACT_LOG_H
#define MSAC_ABSTRACT_LOG_H

#import <Foundation/Foundation.h>

NS_SWIFT_NAME(AbstractLog)
@interface MSACAbstractLog : NSObject

@end

#endif
